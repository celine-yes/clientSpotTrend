
import React, { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';

function SignUpPage() {
  const navigate = useNavigate();
  // État local pour stocker les valeurs des champs du formulaire
  const [formData, setFormData] = useState({
    pseudo: '',
    password: '',
  });

  // Gère la mise à jour de l'état local lorsque les champs du formulaire changent
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  // Gère la soumission du formulaire
  const handleSubmit = (e) => {
    e.preventDefault();
    signUp(formData.pseudo, formData.password)
      .then(() => {
        alert('Inscription réussie !');
        navigate('/signin'); // Redirigez vers SignInPage
      })
      .catch((error) => {
        console.error('Erreur lors de l\'inscription:', error);
        // Utiliser error.message pour obtenir le message d'erreur
        alert(`${error.message}`);
      });
};

  return (
    <div className="signup-page">
      <h1>Inscription</h1>
      <form onSubmit={handleSubmit}>
        <div>
          <label htmlFor="pseudo">Pseudo :</label>
          <input
            type="text"
            id="pseudo"
            name="pseudo"
            value={formData.pseudo}
            onChange={handleChange}
            required
          />
        </div>
        <div>
          <label htmlFor="password">Mot de passe :</label>
          <input
            type="password"
            id="password"
            name="password"
            value={formData.password}
            onChange={handleChange}
            required
          />
        </div>
        <button type="submit">S'inscrire</button>
      </form>
    </div>
  );
}


async function signUp(pseudo, password) {
  const response = await fetch('http://localhost:8080/signup', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ pseudo, password }),
  });
  if (!response.ok) {
    // Lire le texte de la réponse pour obtenir le message d'erreur
    return response.text().then(text => Promise.reject(new Error(text || 'Échec de l\'inscription')));
  }
  return await response.json();
}
export default SignUpPage;
