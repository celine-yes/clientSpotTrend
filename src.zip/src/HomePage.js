
import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import logo from './logo.svg'; 
import userIcon from './user.svg'; 
import logoutIcon from './logout.svg'; 

function HomePage() {
  const [isConnected, setIsConnected] = useState(!!localStorage.getItem('userToken')); // Détermine si l'utilisateur est connecté
  const [topPlayers, setTopPlayers] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const navigate = useNavigate();

  // Ce useEffect surveille les changements dans localStorage pour 'userToken'
  useEffect(() => {
    // Définir une fonction pour gérer les événements de stockage
    const handleStorageChange = () => {
      setIsConnected(!!localStorage.getItem('userToken'));
    };

    // Ajouter un écouteur d'événements sur le stockage pour réagir aux changements
    window.addEventListener('storage', handleStorageChange);

    // Fonction de nettoyage pour supprimer l'écouteur
    return () => window.removeEventListener('storage', handleStorageChange);
  }, []);

  useEffect(() => {
  // Si isConnected a changé et est faux, alors l'utilisateur vient de se déconnecter
  if (!isConnected) {
    navigate('/'); // Optionnel: redirige l'utilisateur ou affiche un contenu spécifique
  } else {
    // Logique pour charger les topPlayers, soit depuis localStorage soit depuis le serveur
    const savedTopPlayers = localStorage.getItem('topPlayers');
    if (savedTopPlayers) {
      setTopPlayers(JSON.parse(savedTopPlayers));
      setIsLoading(false);
    } else {
      async function fetchTopPlayers() {
        try {
          const response = await fetch('http://localhost:8080/topPlayers');
          if (!response.ok) {
            throw new Error('Impossible de récupérer les meilleurs joueurs.');
          }
          const data = await response.json();
          setTopPlayers(data);
        } catch (error) {
          console.error('Erreur lors de la récupération des meilleurs joueurs:', error);
        } finally {
          setIsLoading(false);
        }
      }
      fetchTopPlayers();
    }
    }
  }, [isConnected, navigate]);

  const startQuiz = () => {
    navigate('/quiz'); // Cette fonction redirigera l'utilisateur vers la page du quiz
  };

  const signOut = () => {
    localStorage.removeItem('userToken'); // Supprime le token du localStorage
    setIsConnected(false); 
    //navigate('/'); // Redirige l'utilisateur vers la page de connexion
  };


  //<img src={logo} alt="Logo" className="logo" />

  if (!isConnected) {
    // Si l'utilisateur n'est pas connecté, redirige-le vers la page de connexion ou d'inscription
    return (
      <div className="connect-signup">
        <Link to="/signin" className="btn">Se Connecter</Link>
        <Link to="/signup" className="btn">S'inscrire</Link>
      </div>
    );
  }

  // Si l'utilisateur est connecté, affiche la page principale
  return (
    <div className="main-page">
      <div className="sidebar">
        {/* Logo en haut */}
        <div className="logo-container">
          <Link to="/"><img src={logo} alt="Logo" className="home-logo" /></Link>
        </div>

        {/* Utilisateur et déconnexion en bas */}
        <div className="user-logout-container">
          <Link to="/profile"><img src={userIcon} alt="Profil Utilisateur" className="user-icon" /></Link>
          <img src={logoutIcon} alt="Déconnexion" className="logout-icon" onClick={signOut} style={{cursor: 'pointer'}} />
        </div>
      </div>
      <div className="content">
        <h1>SPOTTREND QUIZ</h1>
        <h2>Classement</h2>
        {isLoading ? (
          <p>Chargement des meilleurs joueurs...</p>
        ) : (
          <table>
          <thead>
            <tr>
              <th>Position</th>
              <th>Pseudo</th>
              <th>Score Total</th>
            </tr>
          </thead>
          <tbody>
            {topPlayers && topPlayers.map((player, index) => (
              <tr key={index}>
                <td>{index + 1}</td>
                <td>{player.pseudo}</td>
                <td>{player.scoreTotal}</td>
              </tr>
            ))}
          </tbody>
        </table>
        )}
        <button className="start-quiz-button" onClick={startQuiz}>COMMENCER</button>
      </div>
    </div>
  );
}

export default HomePage;