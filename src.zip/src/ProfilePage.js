import React, { useState, useEffect } from 'react';
import Table from 'react-bootstrap/Table';
import { useNavigate, Link } from 'react-router-dom';
import logo from './logo.svg'; 
import userIcon from './user.svg';
import logoutIcon from './logout.svg'; 

function ProfilePage() {
  const [userInfo, setUserInfo] = useState(null);
  const [userClassement, setUserClassement] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    async function fetchUserInfo() {
      // Obtenir le token JWT du localStorage
      const token = localStorage.getItem('userToken');
      
      if (!token) {
        console.error('Token is not available');
        setIsLoading(false);
        navigate('/'); // Redirigez l'utilisateur vers la page de connexion si le token n'est pas là
        return;
      }

      try {
        console.log(`profile ${token}`);
        const response = await fetch('http://localhost:8080/userinfo', {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          }
        });

        if (!response.ok) {
          throw new Error('Failed to fetch user info.');
        }

        const data = await response.json();
        setUserInfo(data.userInfo);
        setUserClassement(data.ranking);
      } catch (error) {
        console.error('Erreur lors de la récupération des informations de l\'utilisateur', error);
        navigate('/'); // Redirigez l'utilisateur vers la page de connexion en cas d'erreur
      } finally {
        setIsLoading(false);
      }
    }

    fetchUserInfo();
  }, [navigate]);

  const signOut = () => {
    localStorage.removeItem('userToken'); // Supprime le token du localStorage
    navigate('/');
  };

  if (isLoading) {
    return <p>Chargement des informations de l'utilisateur...</p>;
  }

  if (!userInfo) {
    return <p>Impossible d'afficher les informations de l'utilisateur</p>;
  }

  return (
      <div className="profile-page">
        <div className="sidebar">
          {/* Logo en haut */}
          <div className="logo-container">
            <Link to="/"><img src={logo} alt="Logo" className="home-logo" /></Link>
          </div>

          {/* Utilisateur et déconnexion en bas */}
          <div className="user-logout-container">
            <Link to="/profile"><img src={userIcon} alt="Profil Utilisateur" className="user-icon" /></Link>
            <img src={logoutIcon} alt="Déconnexion" className="logout-icon" onClick={signOut} style={{cursor: 'pointer'}} />
          </div>
        </div>
        <div className="profile-content">
          <h2>{userInfo.pseudo}</h2>
          <p>Nombre de parties : {userInfo.nbDeParties}</p>
          <p>Score total : {userInfo.scoreTotal}</p>
          <h3>Historique des scores</h3>
          {userInfo.scoreHistory && userInfo.scoreHistory.length > 0 ? (
          <table striped bordered hover size="sm">
            <thead>
              <tr>
                <th># Partie</th>
                <th>Score</th>
              </tr>
            </thead>
            <tbody>
              {userInfo.scoreHistory.map((score, index) => (
                <tr key={index}>
                  <td>{index + 1}</td>
                  <td>{score}</td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <p>Aucun historique de score disponible.</p>
        )}
        <h3>Classement</h3>
        {userClassement && userClassement.length > 0 ? (
          <table>
            <thead>
              <tr>
                <th>Position</th>
                <th>Pseudo</th>
                <th>Score</th>
              </tr>
            </thead>
            <tbody>
              {userClassement.map((user, index) => (
                <tr key={index}>
                  <td>{index + 1}</td>
                  <td>{user.pseudo}</td>
                  <td>{user.scoreTotal}</td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <p>Le classement n'est pas encore disponible.</p>
        )}
      </div>
      </div>
  );
}

export default ProfilePage;