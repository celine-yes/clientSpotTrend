import React from 'react';

function ResultPage() {
  return (
    <div>
      <h1>Result</h1>
      {/* Contenu de ta page d'accueil */}
    </div>
  );
}

export default ResultPage;