import React, { useState, useEffect } from 'react';
//import './QuizPage.css';

function QuizPage() {
  const [question, setQuestion] = useState(null);
  const [selectedChoice, setSelectedChoice] = useState(null);
  const [score, setScore] = useState(0);
  const [questionCount, setQuestionCount] = useState(0);
  const [isQuizComplete, setIsQuizComplete] = useState(false);

  useEffect(() => {
    if (!isQuizComplete && questionCount < 10) {
      fetchQuestion();
    }
  }, [questionCount, isQuizComplete]);

  const fetchQuestion = async () => {
    try {
      const response = await fetch('http://localhost:8080/generate-question');
      const data = await response.json();
      setQuestion(data);
      setSelectedChoice(null); //réinitialise pour la question suivante
    } catch (error) {
      console.error('Problème lors de la récupération de la question', error);
    }
  };

  const handleChoice = (choice) => {
    setSelectedChoice(choice);
    if (choice === question.answer) {
      setScore((prevScore) => prevScore + 1);
    }
  };

  const handleNextQuestion = () => {
    if (questionCount < 9) { // car on commence à partir de 0
      setQuestionCount((prevCount) => prevCount + 1);
    } else {
      setIsQuizComplete(true);
    }
    setSelectedChoice(null); //réinitialise pour la question suivante
  };

  const getButtonClass = (choice) => {
    if (selectedChoice === null) return "choice-button";
    if (choice === question.answer) return "choice-button correct";
    if (choice === selectedChoice) return "choice-button incorrect";
    return "choice-button";
  };

  return (
    <div className="quiz-page">
      <h1>SpotTrend Quiz</h1>
      {isQuizComplete ? (
        <div className="quiz-complete">
          <h2>Quiz Terminé!</h2>
          <p>Votre score final: {score}</p>
          {/* Ici, vous pouvez ajouter des actions pour recommencer ou quitter */}
        </div>
      ) : (
        question && (
          <div className="question-container">
            <p className="question-title">Quel morceau a été le plus streamé ?</p>
            <div className="choices-container">
              {question.choices.map((choice, index) => (
                <button
                  key={index}
                  onClick={() => handleChoice(choice)}
                  className={getButtonClass(choice)}
                  disabled={selectedChoice != null}
                >
                  {choice}
                </button>
              ))}
            </div>
            <p>Question: {questionCount + 1} / 10</p>
            <p>Score: {score}</p>
            {selectedChoice && (
              <button className="next-question-button" onClick={handleNextQuestion}>
                Question Suivante
              </button>
            )}
          </div>
        )
      )}
    </div>
  );
}

export default QuizPage;
